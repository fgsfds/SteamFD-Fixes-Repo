All mods require an "init.cfg" to be recognized by the launcher.

The oozie model is a hex-edited version of 'models/e02/monst/oozie_right.grn'.
Two bones were renamed so that it would work properly as a player weapon model.

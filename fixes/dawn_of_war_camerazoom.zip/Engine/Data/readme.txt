=============================
----Dawn of War Mini-Mod----
=============================

=============================
--------By Alex Gnome--------
=============================

=============================
---------Installation--------
=============================
Very simple, move the three camera .lua files (camera_ed.lua, camera_high.lua, and camera_low.lua) into the Engine\Data folder in your Dawn of War install folder (The W40k\Data folder works too if that's what floats your boat.)  You DO NOT need the original to use this.  It is a stand alone mod.  For those of you who have the original, thank you for downloading it, and all you need to do is put this one in the same folder, and over-write the old ones.

=============================
---------1.2 Changes---------
=============================
I lowered the field of view width from the 1.1 (it is still higher than the original though), and I reverted the defualt angle to the orignal.  The field of view was lowered because it didn't look good (it curved the edges) amd the angle was reverted because I didn't like it.  The previous stuff still remains the same.

=============================
---------1.1 Changes---------
=============================
I have fixed the .lua files so now you won't see the foggish haze over everything now.  However the fog bank of doom still lies in the distance, and I can't fix that at the moment as far as I know.  I also zoomed you in a bit, because I was kind of feeling ditattched (don't worry, it's not that much, frankly I can't really tell.)  I also changed the view width for those of you who notice.
The bottom part of the Readme is still from the 1.0, I didn't feel like changing it, but keep in mind I got rid of the haze over the buildings, but I still need help on how to get trid of the sky/fog effect that keeps you from seeing in the distance.

=============================
--------What it does---------
=============================
It allows you to zoom out farther than normal to get a somewhat better view of the battle field.  I would have liked to zoomed out farther, but the games render in fog and sky.  These combine to make seeing things harder when zoomed out any farther than I have them.  As you may notice you can start to see the fog a little from this distance (it's a faint white haze).  As of now, I do not know how, if it is even possible, to turn these off and allow for more zooming.  The only way I know how to get it kind of turned off is in the Mission Editor that comes with the RDN ToolSet.  However this only works while in the ME, and even if you do save it, it does not carry over to the game.

=============================
Think you can make it better?
=============================
If you know how to turn off the fog and sky rendering, please do one (or both) of two things:
A.)Email me at gnome5@hotmail.com how to remove it or
B.)Make it yourself.  The fact is I as a player would love to be able to zoom out even farther, and so if you are better at this than I, or just know how to do it, then I would love to have it.

=============================
-----------Issues------------
=============================
I seriously doubt there will be any issues since this is fairly basic, but if there are, send them to gnome5@hotmail.com.  This is only for problems, and thus the subject on the email should indicate that, otherwise I might just delete it and not respond.
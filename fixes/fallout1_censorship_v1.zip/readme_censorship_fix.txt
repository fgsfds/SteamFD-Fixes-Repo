Fallout 1.2 (Eng) Censorship Fix

-restores children, dialogue and skilldex.
-resets language filter to english (can be turned on/off in game preferences).

SETUP

1. Extract .zip file to your fallout installation directory, overwriting files.

NOTES

- For digital store (Steam/GOG) version, and censored version found on compilation DVD's.
- Children may not appear in all locations unless you start a new game.

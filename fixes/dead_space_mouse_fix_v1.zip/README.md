# What is this?

This fix makes Dead Space use raw mouse input without any additional smoothing or acceleration. It works with VSync and high frame rates and is easy to install without having to fiddle around with FPS limiters or config files.

# Overview

## Description

The mouse controls in Dead Space are notorious. While many players report issues with positive or negative mouse acceleration or overall sluggish movement, others state that the controls are not that bad. This is because the engine applies a lot of transformations to the input that are based on frame time. This leads to movement that is generally better when the frame rate ist stable. The problem gets worse when activating V-Sync. This is why popular workarounds recommend to disable V-Sync and cap the frame rate to avoid fluctuations. 

Unfortunately, this also means that playing at higher frame rates is often not feasible, which also prevents users from taking advantage of GSync, FreeSync, Fast Sync or similar technologies. 

This fix attempts to circumvent those problems by acquiring raw mouse input and injecting it directly into the game's camera functions, making the controls as independent of the frame rate as possible.

While the movement is still not as perfect as in other games -- e.g. DOOM -- it should be a huge improvement to the default behavior.

## Features

* Raw mouse input independent of FPS or VSync
* Reasonable sensitivity range
* Same sensitivity in each direction
* No dead zone for slow movement
* No additional smoothing or positive/negative mouse acceleration
* Improved mouse cursor
* No automatic camera re-center
* Configuration via the ingame settings as usual
* Simple installation and usage without any external configuration

> **Note:** Although the input is pretty *raw* when aiming, it may still feel a little bit sluggish when moving and turning the camera at the same time. This is because the game applies calculations based on the momentum of the player character to the input.

# Instructions

## Supported Versions

> **Important:** This fix relies on the latest, fully patched executables of the supported versions. Older versions or ones that otherwise have been tempered with might not work.

* Steam
* GOG
* Origin*

*The Origin version might crash on start when the ingame overlay is enabled. If that happens, disable the overlay in the game properties in Origin. If the game still crashes the problem might be unrelated to the fix as this is an ongoing issue with the Origin version. In that case uninstall the fix and try to resolve the issue first before installing the fix again.

## Install

> **Note:** The fix does not make any permanent changes to the game or the system and can easily be removed (see below).

1. Extract the file `dinput8.dll` to your main game folder*. For example: `"C:\Program Files (x86)\Steam\steamapps\common\Dead Space"`
2. Start the game like you would normally, for example directly through Steam, Origin or GOG Galaxy

*See *Loading Other Fixes/Mods/Injectors* for information on how to use the fix with another fix, mod or injector that uses a DLL file with the same name.

## Uninstall

1. Remove or rename the `dinput8.dll` from the folder of the game.

## How To Use

After the installation the fix does not require any additional treatment. Just launch the game as usual.

To change the sensitivity just use the ingame settings like you would normally. The fix also incorporates the x- and y-axis inversion settings.

## Loading Other Fixes/Mods/Injectors

To increase the compatibility with other fixes, mods or injectors that are also using a `dinput8.dll`, this fix offers a remote loading feature of additional DLLs. This can be done in two ways:

* **File method:** The fix DLL will automatically load a DLL that has the same name as itself with the postfix `_Remote` added to it. For example `dinput8_Remote.dll`. Just rename the DLL file you want to load accordingly. This is the simplest way if you only have a conflict with one additional DLL
* **Folder method:** The fix DLL will also automatically load **all** DLL files regardless of their name in a sub-directory that has the same name as itself with the postfix `_Remote` added to it. For example `dinput8_Remote`. Just create a folder with the corresponding name in the install directory of the fix. This is the only way to load multiple (conflicting) DLLs

> **Note:** There might still be compatibility issues between the different fixes, mods or injectors that have nothing to do with the loading process.

# Additional Information

## What You Should Know

This fix is essentially a hack and relies on the layout of the specific executable. There may be crashes or unexpected issues. Feel free to provide feedback so that the problems can get fixed.

Since this fix consists of an executable DLL-File, I could have put any harmful shenanigans in there. You just have to trust me that the file is clean.

If you don't -- and why should you -- feel free to use a meta online virus scanner like VirusTotal to verify the file. Be aware however, that because the fix uses "hacking techniques" such as injection and hooking, it could trigger anti-virus software without being harmful.

## Known Issues

There are currently no known issues with the fix.

## Acknowledgments

I would like to thank Magmarock (Steam/gog) for his detailed bug reports and testing for the v1.0 version of the fix.

## Contact And Support

If you like this fix and want to support the development or show your appreciation, you can find more information on my [website](https://methanhydrat.wordpress.com/). There you can also find out more about other fixes that I have done and means to contact me if you have a question, want to provide feedback, bug reports or suggestions.

## Version History

### v1.0:
* Camera movement is now constrained to the original angles. This also fixes spinning issues in zero-g
* Using the breadcrumbs will now turn the character as intended
* Using the mouse modifier key in a menu will no longer cause the camera to jerk when closing the menu again
* Opening a cursor-driven menu will no longer cause the camera to jerk when closing the menu again
* Setting the sensitivity to the lowest value no longer prevents the camera and cursor movement entirely
* Improved mouse cursor
* The mouse cursor is now independent of camera sensitivity
* The camera will no longer automatically re-center
* The fix should now work with almost every version of the game
* The fix now offers an option to remotely load DLLs of other fixes, mods or injectors (see *Loading Other Fixes/Mods/Injectors* for details)

### v0.5.1 Beta - Hotfix:
* Fixed bug that caused the Steam and retail version to crash on start

### v0.5 Beta:
* The fix should now correctly work with Origin versions from any region

### v0.4 Beta:
* Added MessageBox to inform users when the fix cannot be loaded (e.g. using it on an unsupported version)

### v0.3 Beta:
* Added support for GOG and Origin versions of the game

### v0.2 Beta:
* Added support for x- and y-axis inversion

### v0.1 Beta:
* Initial release
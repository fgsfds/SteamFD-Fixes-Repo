Widescreen fix for Beyond Good and Evil
Created by nemesis2000 <nemesis2000@yandex.ru>
Downloaded from http://ps2wide.net/pc.html

Installation Instructions
=========================================================================

1. Unpack [password: bge]
2. Edit bge.ini
3. Enjoy


Additional Information
=========================================================================

1. Supported exe size: 7�778�304 bytes (gog version / buka version); 7 819 264 bytes; 7 489 200 bytes (Uplay version); 7 894 696 bytes (Uplay version); 7 884 800 bytes (Uplay version);


References
=========================================================================

1. UPX: the Ultimate Packer for eXecutables <http://upx.sourceforge.net/>
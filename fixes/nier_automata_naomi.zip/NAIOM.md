# TL;DR

This mod fixes various mouse and keyboard related input issues in NieR: Automata. Its features include raw mouse input for camera and aim movement, an entirely new crosshair aiming mode, non-standard bindings for dash/evade, pod auto-fire and more.

Quick start guide:

**Important: If you currently have NAIOM v1.3.0 or older installed, remove the `XInput1_3.dll` from the games's directory first!**

1. Extract the file `dinput8.dll` and `NAIOM-GUI.exe` to your main game folder. For example: `"C:\Program Files (x86)\Steam\steamapps\common\NieRAutomata"`
2. Start `NAIOM-GUI.exe` and set the bindings and other settings as desired
3. Start the game like you would normally, for example directly through Steam 

# Features 

The NieR: Automata Input Overhaul Mod (NAIOM) aims to solve all keyboard and mouse related issues in the game. As many other rough PC ports, NieR was primarily designed with a controller in mind and internally maps keyboard and mouse input to gamepad controls. This leads to various issue, including negative and positive mouse acceleration, as well as weird controls in certain perspectives, e.g. when aiming in side-scrolling mode.

Its features include:

* Raw mouse input without any acceleration or smoothing
* Precise sensitivity configuration (calibrated for KovaaK's SensitivityMatcher)
* Fixed camera movement in third-person perspective
* New (optional) crosshair aiming mode for side-scrolling and top-down perspective
* New (optional) mouse cursors for menu and hacking (made by DevianArt user JulioDRai)
* Completely rebindable standard actions to any key or button combination including additional mouse buttons
* Non-standard keybindings, such as a dedicated dash/evade and pod fire toggle
* Compatible with FAR/SpecialK mod ([must be configured to **not** use `dinput8.dll`](https://wiki.special-k.info/en/SpecialK/Local))

# Instructions

## Supported Versions

* Steam (patch 1, including YoRHa Edition)

## Install

The mod does not make any permanent changes to the game or to Windows and can easily be removed.

**Important: If you currently have NAIOM v1.3.0 or older installed, remove the `XInput1_3.dll` from the games's directory first!**

1. Extract the file `dinput8.dll` and `NAIOM-GUI.exe` to your main game folder. For example: `"C:\Program Files (x86)\Steam\steamapps\common\NieRAutomata\"`
2. Start `NAIOM-GUI.exe` and set the bindings and other settings as desired (see *GUI Requirements* if you have trouble running the GUI)
3. Start the game like you would normally, for example directly through Steam 

Note that even though the GUI is for configuration only and does not have to be running for the mod to work, it can be used together with the 'Reload Config' binding to adjust options of the fly.

## Update

1. If you currently have NAIOM v1.3.0 or older installed, remove the `XInput1_3.dll` from the games's directory
2. Perform a regular installation and just overwrite any existing files

Note that an update retains all configured options unless they have actually been changed or removed in the new version.

## Uninstall

1. Remove or rename the `dinput8.dll` from the folder of the game.

# Known Issues

* In the third-person view the camera might sometimes judder when it is near obstacles, such as walls. This has only partially to do with the mod, since the issue also occurs without it, but might just be more noticeable with it enabled
* Using the bindings of the mod does currently not change the ingame button prompts
* The new aiming mod crosshair is sometimes slightly misaligned
* When using the new aiming mode the crosshair does currently also activate in situations where the aiming direction is fixed, e.g. in the side-scrolling flying mode
* The non-standard item switch bindings currently do not work as described in the tooltip when certain items are equipped
* The mod is currently not entirely compatible with the GeForce Experience overlay, which may not be controllable with the mouse in certain situations. However, the actual functionality can still be accessed by using the corresponding hotkeys
* The crosshair does currently not work in the hacking minigame and the standard mouse cursor will be shown instead

# Additional Information

## Antivirus Software

Since this mod consists of an executable DLL file that uses "hacking techniques" such as injection and hooking, it could be classified as malicious by antivirus software. In that case, it might be necessary to add an exception rule to the scanner.

If you lack the trust in random people on the internet -- and I would not blame you -- feel free to use a meta online virus scanner like VirusTotal to verify the file.

## GUI Requirements

The GUI requires both the Microsoft Visual C++ Redistributable 2019 and .NET Core 3.1 runtime packages to work; which should already be installed on most systems. If you are having problems starting the program, you can download the required versions either through a recommended Windows update (Windows 7 and later) or at Microsoft [here](https://support.microsoft.com/en-us/help/2977003/the-latest-supported-visual-c-downloads) and [here](https://dotnet.microsoft.com/download/dotnet/thank-you/runtime-desktop-3.1.0-windows-x64-installer).

## Loading Other Fixes/Mods/Injectors

To increase the compatibility with other mods or injectors that are using a wrapper DLL, this fix offers two methods for remote loading of additional files. Note that there might still be compatibility issues between the different fixes, mods or injectors that have nothing to do with the loading process.

### File method:

The mod will load another `dinput8.dll` automatically if it has the name `dinput8_Remote.dll`. Just rename the DLL you want to load accordingly. Using this method will lead to an error if the renamed DLL is not itself a `dinput8.dll`.

### Folder method:

The mod will also automatically load all DLLs regardless of their names in a `dinput8_Remote` sub-directory. Just create a corresponding folder in the install directory of the mod. This is the only way to load multiple (conflicting) files.

## Input Bindings

The GUI allows the binding of an action to an arbitrary combination of keys and buttons on the keyboard, the mouse or an XInput compatible controller. The system purposefully does not restrict conflicts, so multiple actions can be bound to the same key.

### Key Names:

In case of the keyboard there might be a discrepancy between the key that was pressed and the one that is displayed. This is because the names are automatically translated based on the keyboard layout by using a Windows function. However, the mod always uses the physical keys as they were used during the creation of the binding, independent of the name that is displayed.

### Modifiers:

Modifier bindings can be created by just using the corresponding key combinations. If you bind one action to *Space* and another another to *LCTRL + Space* and a third one to *LALT + LCTRL + Space*, only one of them will be triggered when *Space* is down, depending on the state of *LCTRL* and *LALT*. The system is not restricted to the usual modifier keys ALT, CTRL or SHIFT. Any key or button pressed before another acts as a modifier for the next one. Note that the order of the keys or buttons is only relevant during the binding process to distinguish bindings with the same modifiers. In the above example, *Space* could be held down and the other actions triggered by pressing *LCTRL* or *LALT* afterwards.

# Acknowledgments

I would like to thank Kaibz for his continuous testing during the pre-release development of the mod. Without his detailed feedback and suggestions, creating the mod would have taken even longer than it already did.

I also would like to thank DevianArt user JulioDRai for creating the [awesome custom cursor package](https://www.deviantart.com/juliodrai/art/Nier-Automata-Cursor-Hack-Edition-v2-736152335) that is used by this mod.

# Contact And Support

If you like this mod and want to support the development or show your appreciation with a donation, you can find more information on my [website](https://methanhydrat.wordpress.com/). There you can also find out more about other mods that I have done and means to contact me if you have a question, want to provide feedback, bug reports and suggestions.

# Version History

## v1.4.0:
* Migrated mod to game version v1.1/patch 1
* Migrated GUI to .NET Core 3.1
* Fixed pursuit speed when third-person fix is disabled
* Mitigated judder near ground and walls when third-person fix is enabled

## v1.3:
* Added (optional) custom mouse cursors for menu and hacking
* Added dedicated binding for opening the after clearance debug menu
* Fixed regular fire binding behavior when being held down
* Fixed hacking while remote controlling an enemy
* Fixed an issue with "sticky keys" after exiting a menu or dialog
* Fixed mouse button control in menus that occurred after hacking an enemy
* Fixed crash that occurred on certain systems when exiting the game

## v1.2:
* Added pattern based game version compatibility check
* Overhauled crosshair aiming mode to use the (hidden) mouse cursor for controlling the aim
* Increased crosshair aiming precision
* Reduced input lag of crosshair
* Fixed crosshair alignment in certain perspectives
* Fixed aiming in hacking mode
* Fixed a loading error that occurred on certain system configurations
* Fixed a bug that prevented certain clothing items to be equipped properly when pod petting was disabled
* Fixed a bug that prevented the mod from being loaded at all if the Steam controller mode was enabled

## v1.1:
* The dedicated dodge binding now has the same distance and duration as the double tap version

## v1.0:
* Initial public release
SilentPatch - DDraw component for GTA III and GTA VC
Build 5
Last update - 20.05.2018


DESCRIPTION

	This ddraw.dll component fixes some game issues which couldn't be addressed from within SilentPatchIII.asi or
	SilentPatchVC.asi due to the fact ASI files load relatively late in those games.

	Fixes featured in this plugin:

	* If the settings file is absent, the game will now default to your desktop resolution instead of 640x480x16
	* DirectPlay dependency has been removed - this should improve compatibility with Windows 8 and newer
	* The game will not crash on startup if Data Execution Prevention is enabled for all applications anymore
	* "Cannot find enough available video memory" error showing on some computers has been removed
	* Path to the User Files directory is now obtained differently, hopefully increasing compatibility and
	  future-proofing the games more
	* FILE_FLAG_NO_BUFFERING flag has been removed from IMG reading functions - speeding up streaming
	* All censorships from German and French versions of the game have been removed
	* Fixed an issue which would cause games to freeze if III/VC/SA were running at the same time


INSTALLATION

	Installation is easy as pie. Just extract the archive contents to your game directory and that's all!


SUPPORTED GAME VERSIONS

	* GTA III 1.0 (all versions)
	* GTA III 1.1 (all versions, including Steam version)
	* GTA VC 1.0 (all versions)
	* GTA VC 1.1 (all versions, including Steam version)


CREDITS

	NTAuthority - DirectPlay dependency removal code


CONTACT

	zdanio95@gmail.com - e-mail
	Silent#1222 - Discord

Subscribe to my YouTube channel for more footage from my mods!
https://www.youtube.com/user/CookiePLMonster

Follow my Twitter account to be up to all my mods updates!
http://twitter.com/__silent_
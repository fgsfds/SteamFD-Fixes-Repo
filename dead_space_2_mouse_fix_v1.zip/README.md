# TL;DR

This fix makes Dead Space 2 use raw mouse input without any additional smoothing or acceleration. It works with VSync and high frame rates and is easy to install without having to fiddle around with FPS limiters or config files.

Quick start guide:

1. Extract the file `dinput8.dll` to your main game folder. For example: `"C:\Program Files (x86)\Origin\games\Dead Space 2\"`.
2. Start the game like you would normally, for example directly through Origin or Steam

# Features

Even though the mouse controls in Dead Space 2 are better than in the first one, it still suffers from many of the same issues. Most notably, it has negative mouse acceleration and a sensitivity that is dependent on the frame rate, which leads to inconsistent movement when the performance is not stable.

This fix circumvents those problems by acquiring raw mouse input and injecting it directly into the game's camera functions.

Its features include:

* Raw mouse input independent of FPS or VSync
* Reasonable sensitivity range
* Same sensitivity in each direction
* No dead zone for slow movement
* No additional smoothing or positive/negative mouse acceleration
* Improved mouse cursor
* No automatic camera re-center
* Configuration via the ingame settings as usual
* Simple installation and usage without any external configuration

# Instructions

## Supported Versions

This mod is designed for the latest, fully patched versions of Dead Space 2 and might not work when used with older or otherwise modified executables.

* Origin/Retail
* Steam

## Install

The mod does not make any permanent changes to the game or to Windows and can easily be removed.

1. Extract the file `dinput8.dll` to your main game folder. For example: `"C:\Program Files (x86)\Origin\games\Dead Space 2\"`.
2. Start the game like you would normally, for example directly through Origin or Steam

## Uninstall

1. Remove or rename the `dinput8.dll` from the folder of the game.

# Known Issues

There are some short sections in the game where the fix does not work properly, for example the zero-g areas. I am currently looking for savegames close to those locations, so I can investigate the issues.

The fix is also currently not compatible with latest version of ReShade, due to raw input conflicts, which result in the fix not receiving any mouse data.

# Additional Information

## Antivirus Software

Since this mod consists of an executable DLL file that uses "hacking techniques" such as injection and hooking, it could be classified as malicious by antivirus software. In that case, it might be necessary to add an exception rule to the scanner.

If you lack the trust in random people on the internet -- and I would not blame you -- feel free to use a meta online virus scanner like VirusTotal to verify the file.

## Loading Other Fixes/Mods/Injectors

To increase the compatibility with other mods or injectors that are using a wrapper DLL, this fix offers two methods for remote loading of additional files. Note that there might still be compatibility issues between the different fixes, mods or injectors that have nothing to do with the loading process.

### File method:

The mod will load another `dinput8.dll` automatically if it has the name `dinput8_Remote.dll`. Just rename the DLL you want to load accordingly. Using this method will lead to an error if the renamed DLL is not itself a `dinput8.dll`.

### Folder method:

The mod will also automatically load all DLLs regardless of their names in a `dinput8_Remote` sub-directory. Just create a corresponding folder in the install directory of the mod. This is the only way to load multiple (conflicting) files.

# Acknowledgments

I would like to thank Kaibz for his detailed bug reports and testing for the v1.0 version of the fix.

# Contact And Support

If you like this fix and want to support the development or show your appreciation with a donation, you can find more information on my [website](https://methanhydrat.wordpress.com/). There you can also find out more about other mods that I have done and means to contact me if you have a question, want to provide feedback, bug reports and suggestions.

# Version History

## v1.2.1:
* Fixed Steam version support
* Fixed a launch issue on Windows 7

## v1.2:
* Updated address system to increase compatibility with modified versions of the game
* Added support for remote loading of additional DLLs to increase the compatibility with other mods (see *Loading Other Fixes/Mods/Injectors*)
* Fixed compatibility issues with certain mods and tools

## v1.1 (unreleased):
* Internal changes

## v1.0:
* Initial public release